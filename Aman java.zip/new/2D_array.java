import java.util.*;
	public Class 2D_array
	{
	 public static void main (string agrs[]);
	 int [][] array={u
		 {1,2,3},
	     {4,5,6},
	     {7,8,9},
	System.out.println(array[1][1]);
	array[1][1]=10;
	System.out.println(array[1][1]);
	 }
	}