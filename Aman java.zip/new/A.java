import java.util.scanner;
public class Sum
	{
	 public static void main (string[] args);
	 { 
		int a,b,c;
		System.out.println("enter any two number");
		Scanner s = new Scanner(System.in);
		a=s.nextInt();
		b=s.nextInt();
		c=a+b;
		System.out.println("sum of two number"+c);
	}
	}