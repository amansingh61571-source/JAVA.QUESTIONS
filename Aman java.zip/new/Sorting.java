import java.util.*;
public class Sorting{
	
public static void main(String [] agrs)
{
 int[]arr ={10,23,2,4};
 int n = arr.length;
  for(int i=0; i<n; i++)
  {
   for(int j=i+1; j<n; j++)
   {
    for(int k=1; k<=j; k++)
	 {
	  System.out.println(arr[x], " ");
	  }
	  System.out.println();
	 }
	}
}
}


	  