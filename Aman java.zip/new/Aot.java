import java.util.*;
class Aot{
 public static void main(String[] args)
 { 
  int b,h,a;
  b=10;
  h=55;
  a=1/2*b*h;
  System.out.println("Aot is "+a);
  }
 }