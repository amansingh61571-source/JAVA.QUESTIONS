import java.util.*;
	public class Tostring{
	 public static void main (string[] args)
	 {
	  arr=[7,1,9,4,3]
	  int temp=arr[n-1];
	  for(int i=n-2; i>=0; i--)
	  {
	   arr[i+1]=arr[i];
	  }
	  arr[0]=temp;
	  {
	  system.out.println(array.tostring(arr));
	 }
	 }
	 