import java.util.scanner;
class evenodd
public static void main(string[] args)
{
 int num;
  scanner.reader= new scanner(system.in)
  system.out.println("enter no");
  num= reader.nextInt();
   if (num%2==0)
   {
	system.out.println(num+"even");
   }
   else
   {
    system.out.println(num+"odd");
	}
   }
  }