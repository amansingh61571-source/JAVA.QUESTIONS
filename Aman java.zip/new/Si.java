import java.util.*;
class Si{
 public static void main(String[] args)
 {
  Scanner sc = new Scanner (System.in);
   System.out.println("Enter value of p");
   int p=sc.nextInt();
   System.out.println("Enter value of r");
   int r=sc.nextInt();
   System.out.println("Enter value of t");
   int t=sc.nextInt();
   int SI= p*r*t/100;
   {
    System.out.println("value of SI "+SI);
   
  }
 }
}