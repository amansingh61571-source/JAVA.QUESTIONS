import java.util.Scanner;
	class Integer {
		public static void main(String[] argument)
		{
			int c;
			for(c=1; c<=10; c++)
			{
			 System.out.println(c);
			}
		}
	}
