import java.util.*;
public class Pro {

public static void main(String[ ] args) {

    int[ ] ar1 = { 5, 6, 3, 2, 1 };
	int[ ] ar2 = { 7, 4, 4, 5, 6 };
    // Print all the array elements
		int sum=ar1+ar2;
    for (int i = 0; i < ar1.length; i++) 
	{
        System.out.println("Index :- "+i+" Value :- "+ar1[i]);
    }
}

}

            