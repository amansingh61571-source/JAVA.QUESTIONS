class Xyz
{
 int a,b;
 static int c;
 static void show()
 {
  System.out.print("Hello Inside");
 }
 public static void main(String args[])
 {
 Xyz ob=new Xyz();
 show();
 }
 }